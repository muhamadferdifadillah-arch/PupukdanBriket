

<?php $__env->startSection('title', 'Pesanan Saya - Manfaatin'); ?>

<?php $__env->startSection('content'); ?>
<div class="orders-page" style="background: #f8f9fa; min-height: 100vh; padding: 40px 0;">

    <div class="container">

        
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb" style="background: transparent; padding: 0;">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" style="color: #6c757d; text-decoration: none;">Home</a></li>
                <li class="breadcrumb-item active" style="color: #2d3748;">Pesanan Saya</li>
            </ol>
        </nav>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="fw-bold mb-1" style="color: #2d3748; font-size: 2rem;">Pesanan Saya</h1>
                <p class="text-muted mb-0">Kelola dan lacak semua pesanan Anda</p>
            </div>
        </div>

        
        <div class="card border-0 shadow-sm mb-4" style="border-radius: 12px;">
            <div class="card-body p-3">
                <form action="<?php echo e(route('user.orders')); ?>" method="GET">
                    <div class="row g-2 align-items-center">
                        <div class="col-md-10">
                            <div class="input-group">
                                <span class="input-group-text bg-white border-end-0" style="border-radius: 8px 0 0 8px; border-color: #e9ecef;">
                                    <i class="fas fa-search text-muted"></i>
                                </span>
                                <input type="text" name="search" class="form-control border-start-0 shadow-none"
                                       placeholder="Cari nomor pesanan atau nama produk..."
                                       value="<?php echo e(request('search')); ?>"
                                       style="border-radius: 0 8px 8px 0; border-color: #e9ecef;">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-success w-100" type="submit" style="border-radius: 8px; padding: 10px;">
                                Cari
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        
        <div class="card border-0 shadow-sm mb-4" style="border-radius: 12px;">
            <div class="card-body p-3">
                <div class="d-flex flex-wrap gap-2">

                    <?php
                        $statuses = [
                            'all' => ['label'=>'Semua', 'color'=>'#6c757d'],
                            'pending' => ['label'=>'Menunggu Pembayaran', 'color'=>'#ffc107'],
                            'processing' => ['label'=>'Diproses', 'color'=>'#0dcaf0'],
                            'shipping' => ['label'=>'Dikirim', 'color'=>'#0d6efd'],
                            'completed' => ['label'=>'Selesai', 'color'=>'#198754'],
                            'cancelled' => ['label'=>'Dibatalkan', 'color'=>'#dc3545'],
                        ];
                    ?>

                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($key === 'all' ? route('user.orders') : route('user.orders', ['status'=>$key])); ?>"
                       class="status-tab <?php echo e((!request('status') && $key === 'all') || request('status') == $key ? 'active' : ''); ?>"
                       style="padding: 10px 20px; border-radius: 8px; text-decoration: none; border: 1px solid <?php echo e((!request('status') && $key === 'all') || request('status') == $key ? $row['color'] : '#dee2e6'); ?>; color: <?php echo e((!request('status') && $key === 'all') || request('status') == $key ? 'white' : '#6c757d'); ?>; background: <?php echo e((!request('status') && $key === 'all') || request('status') == $key ? $row['color'] : 'white'); ?>; font-size: 0.9rem; transition: all 0.2s;">
                        <?php echo e($row['label']); ?>

                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>

        
        <?php if($orders->count() > 0): ?>
            <div class="row">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 mb-3">
                    <div class="card border-0 shadow-sm" style="border-radius: 12px; transition: all 0.2s;">

                        <div class="card-body p-4">

                            
                            <div class="d-flex justify-content-between align-items-start mb-3 pb-3 border-bottom">
                                <div>
                                    <div class="d-flex align-items-center gap-2 mb-1">
                                        <h6 class="mb-0 fw-bold"><?php echo e($order->order_number); ?></h6>

                                        
                                        <?php
                                            $statusConfig = [
                                                'completed'=>['bg'=>'#198754', 'text'=>'Selesai'],
                                                'shipping'=>['bg'=>'#0d6efd', 'text'=>'Dikirim'],
                                                'processing'=>['bg'=>'#0dcaf0', 'text'=>'Diproses'],
                                                'pending'=>['bg'=>'#ffc107', 'text'=>'Menunggu Pembayaran'],
                                                'cancelled'=>['bg'=>'#dc3545', 'text'=>'Dibatalkan']
                                            ];
                                            $currentStatus = $statusConfig[$order->status] ?? ['bg'=>'#6c757d', 'text'=>'Unknown'];
                                        ?>

                                        <span class="badge" style="background: <?php echo e($currentStatus['bg']); ?>; font-size: 0.75rem; padding: 4px 10px; font-weight: 500;">
                                            <?php echo e($currentStatus['text']); ?>

                                        </span>
                                    </div>

                                    <small class="text-muted">
                                        <i class="far fa-calendar me-1"></i>
                                        <?php echo e($order->created_at->format('d M Y, H:i')); ?>

                                    </small>
                                </div>

                                <button class="btn btn-sm btn-light toggle-btn" 
                                        data-bs-toggle="collapse"
                                        data-bs-target="#orderDetail<?php echo e($order->id); ?>"
                                        style="border-radius: 6px; border: 1px solid #e9ecef; padding: 6px 12px;">
                                    <i class="fas fa-chevron-down" style="font-size: 0.85rem;"></i>
                                </button>
                            </div>

                            
                            <div class="mb-3">
                                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex align-items-center gap-3 mb-2">
                                    <img src="<?php echo e($item->product->image ? asset('storage/'.$item->product->image) : 'https://via.placeholder.com/60'); ?>"
                                         style="width:60px; height:60px; object-fit:cover; border-radius:8px; border: 1px solid #e9ecef;">

                                    <div class="flex-grow-1">
                                        <h6 class="mb-1" style="font-size: 0.95rem;"><?php echo e($item->product->name); ?></h6>
                                        <small class="text-muted"><?php echo e($item->quantity); ?>x Rp <?php echo e(number_format($item->price,0,',','.')); ?></small>
                                    </div>

                                    <div class="text-end">
                                        <div class="fw-semibold" style="color: #2d3748;">
                                            Rp <?php echo e(number_format($item->price * $item->quantity, 0, ',', '.')); ?>

                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            
                            <div class="d-flex justify-content-between align-items-center pt-3 border-top">
                                <span class="text-muted">Total Pesanan</span>
                                <h5 class="mb-0 fw-bold" style="color: #198754;">
                                    Rp <?php echo e(number_format($order->total_amount,0,',','.')); ?>

                                </h5>
                            </div>

                            
                            <div class="collapse mt-3" id="orderDetail<?php echo e($order->id); ?>">
                                <div class="border-top pt-3">

                                    
                                    <?php if($order->tracking_number): ?>
                                    <div class="mb-3">
                                        <h6 class="fw-semibold mb-2" style="font-size: 0.95rem;">Informasi Pengiriman</h6>
                                        
                                        <div class="row g-2">
                                            <div class="col-md-6">
                                                <small class="text-muted d-block">Alamat Pengiriman</small>
                                                <p class="mb-0" style="font-size: 0.9rem;"><?php echo e($order->shipping_address); ?></p>
                                            </div>
                                            <div class="col-md-6">
                                                <small class="text-muted d-block">Nomor Telepon</small>
                                                <p class="mb-0" style="font-size: 0.9rem;"><?php echo e($order->phone); ?></p>
                                            </div>
                                            <?php if($order->courier): ?>
                                            <div class="col-md-6">
                                                <small class="text-muted d-block">Kurir</small>
                                                <p class="mb-0 text-uppercase" style="font-size: 0.9rem;"><?php echo e($order->courier); ?></p>
                                            </div>
                                            <?php endif; ?>
                                            <div class="col-md-6">
                                                <small class="text-muted d-block">Nomor Resi</small>
                                                <p class="mb-0" style="font-size: 0.9rem;"><?php echo e($order->tracking_number); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    
                                    <div class="bg-light p-3 rounded" style="border-radius: 8px;">
                                        <h6 class="fw-semibold mb-3" style="font-size: 0.95rem;">Ringkasan Pembayaran</h6>
                                        
                                        <div class="d-flex justify-content-between mb-2">
                                            <small class="text-muted">Subtotal Produk</small>
                                            <small class="fw-medium">Rp <?php echo e(number_format($order->orderItems->sum(fn($i)=>$i->price * $i->quantity),0,',','.')); ?></small>
                                        </div>

                                        <div class="d-flex justify-content-between mb-2">
                                            <small class="text-muted">Ongkos Kirim</small>
                                            <small class="fw-medium">Rp <?php echo e(number_format($order->shipping_cost ?? 0,0,',','.')); ?></small>
                                        </div>

                                        <?php if($order->discount > 0): ?>
                                        <div class="d-flex justify-content-between mb-2 text-success">
                                            <small>Diskon</small>
                                            <small class="fw-medium">- Rp <?php echo e(number_format($order->discount,0,',','.')); ?></small>
                                        </div>
                                        <?php endif; ?>

                                        <hr style="margin: 10px 0;">

                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="fw-semibold">Total Pembayaran</span>
                                            <span class="fw-bold text-success">Rp <?php echo e(number_format($order->total_amount,0,',','.')); ?></span>
                                        </div>

                                        <small class="text-muted d-block mt-2">
                                            Metode: <?php echo e(ucfirst($order->payment_method)); ?>

                                        </small>
                                    </div>

                                </div>
                            </div>

                            
                            <div class="d-flex gap-2 mt-3 flex-wrap">
                                
                                <?php if($order->status == 'completed'): ?>
                                    <button class="btn btn-outline-success btn-sm flex-grow-1" style="border-radius: 8px;">
                                        <i class="fas fa-star me-1"></i>Beri Ulasan
                                    </button>
                                    <button class="btn btn-outline-secondary btn-sm" style="border-radius: 8px;">
                                        <i class="fas fa-redo me-1"></i>Beli Lagi
                                    </button>

                                <?php elseif($order->status == 'shipping'): ?>
                                    <form method="POST" action="<?php echo e(route('user.orders.complete',$order->id)); ?>" class="flex-grow-1">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <button class="btn btn-success btn-sm w-100" style="border-radius: 8px;">
                                            <i class="fas fa-check me-1"></i>Pesanan Diterima
                                        </button>
                                    </form>
                                    <button class="btn btn-outline-primary btn-sm" style="border-radius: 8px;">
                                        <i class="fas fa-truck me-1"></i>Lacak
                                    </button>

                                <?php elseif($order->status == 'pending'): ?>
                                    <a href="<?php echo e(route('user.orders.pay',$order->id)); ?>" class="btn btn-success btn-sm flex-grow-1" style="border-radius: 8px;">
                                        <i class="fas fa-wallet me-1"></i>Bayar Sekarang
                                    </a>
                                    <form method="POST" action="<?php echo e(route('user.orders.cancel',$order->id)); ?>">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <button class="btn btn-outline-danger btn-sm" style="border-radius: 8px;"
                                                onclick="return confirm('Yakin batalkan pesanan?')">
                                            <i class="fas fa-times me-1"></i>Batalkan
                                        </button>
                                    </form>

                                <?php elseif($order->status == 'processing'): ?>
                                    <button class="btn btn-outline-primary btn-sm flex-grow-1" style="border-radius: 8px;">
                                        <i class="fas fa-comments me-1"></i>Hubungi Penjual
                                    </button>

                                <?php elseif($order->status == 'cancelled'): ?>
                                    <button class="btn btn-outline-secondary btn-sm flex-grow-1" style="border-radius: 8px;">
                                        <i class="fas fa-shopping-cart me-1"></i>Pesan Lagi
                                    </button>
                                <?php endif; ?>

                            </div>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($orders->withQueryString()->links()); ?>

            </div>

        <?php else: ?>
        
        <div class="text-center py-5">
            <div style="max-width: 400px; margin: 0 auto;">
                <div class="mb-4">
                    <i class="fas fa-shopping-bag" style="font-size: 5rem; color: #dee2e6;"></i>
                </div>
                <h5 class="fw-bold mb-2" style="color: #2d3748;">Belum Ada Pesanan</h5>
                <p class="text-muted mb-4">Mulai belanja dan temukan produk favorit Anda</p>
                <a href="<?php echo e(route('home')); ?>" class="btn btn-success" style="border-radius: 8px; padding: 10px 30px;">
                    <i class="fas fa-shopping-cart me-2"></i>Mulai Belanja
                </a>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>


<style>
.card {
    transition: all 0.2s ease;
}

.card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;
}

.status-tab:hover {
    background: #f8f9fa !important;
    border-color: #dee2e6 !important;
}

.status-tab.active:hover {
    opacity: 0.9;
}

.toggle-btn[aria-expanded="true"] i {
    transform: rotate(180deg);
}

.toggle-btn i {
    transition: transform 0.2s ease;
}

.btn {
    transition: all 0.2s ease;
}

.btn:hover {
    transform: translateY(-1px);
}

/* Responsive */
@media (max-width: 768px) {
    .status-tab {
        font-size: 0.8rem !important;
        padding: 8px 15px !important;
    }
    
    h1 {
        font-size: 1.5rem !important;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PupukdanBriket\resources\views/user/order-user.blade.php ENDPATH**/ ?>