

<?php $__env->startSection('title', $category->name ?? 'Shop Products'); ?>

<?php $__env->startSection('content'); ?>

    <style>
        /* ===== CARD ===== */
        .shop-card {
            background: #ffffff;
            border-radius: 14px;
            overflow: hidden;
            text-align: center;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            height: 100%;
        }

        .shop-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 18px 45px rgba(0, 0, 0, 0.12);
        }

        /* ===== IMAGE ===== */
        .shop-image {
            height: 200px;
            background: #f6f6f6;
        }

        .shop-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* ===== BODY ===== */
        .shop-body {
            padding: 16px;
        }

        .shop-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 8px;
            color: #222;
        }

        .shop-price {
            font-size: 18px;
            font-weight: bold;
            color: #00a651;
            margin-bottom: 14px;
        }

        /* ===== BUTTON ===== */
        .btn-add-cart {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 8px;
            background: #00a651;
            color: #fff;
            font-weight: 600;
            cursor: pointer;
            transition: 0.25s;
        }

        .btn-add-cart:hover {
            background: #008a43;
        }

        .btn-add-cart:disabled {
            background: #cccccc;
            cursor: not-allowed;
        }
    </style>

    <div class="container py-5">

        <h2 class="fw-bold mb-4 text-center">
            <?php echo e($category->name ?? 'Shop Products'); ?>

        </h2>

        <?php if($products->count() > 0): ?>
            <div class="row g-4 justify-content-center">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-4 col-lg-3">

                        <div class="shop-card">

                            <div class="shop-image">
                                <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>"
                                    onerror="this.src='<?php echo e(asset('images/no-image.png')); ?>'">

                            </div>

                            <div class="shop-body">
                                <h5 class="shop-title"><?php echo e($product->name); ?></h5>

                                <p class="shop-price">
                                    Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                                </p>

                                <button class="btn-add-cart" data-id="<?php echo e($product->id); ?>" data-name="<?php echo e($product->name); ?>">
                                    Add to Cart
                                </button>
                            </div>

                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        <?php else: ?>
            <div class="alert alert-info text-center">
                Tidak ada produk.
            </div>
        <?php endif; ?>

    </div>

    
    <script>
        document.addEventListener('DOMContentLoaded', () => {

            document.querySelectorAll('.btn-add-cart').forEach(btn => {
                btn.addEventListener('click', function () {

                    const productId = this.dataset.id;
                    const productName = this.dataset.name;
                    const original = this.innerHTML;
                    const csrf = document.querySelector('meta[name="csrf-token"]').content;

                    this.disabled = true;
                    this.innerHTML = 'Adding...';

                    fetch("<?php echo e(route('cart.add')); ?>", {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrf,
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify({
                            product_id: productId,
                            quantity: 1
                        })
                    })
                        .then(res => res.json())
                        .then(data => {
                            this.disabled = false;
                            this.innerHTML = original;

                            if (data.success) {
                                alert('✓ ' + productName + ' ditambahkan ke cart');

                                const badge = document.querySelector('.cart-count');
                                if (badge) badge.textContent = data.cart_count;
                            } else {
                                alert('✗ ' + data.message);
                            }
                        })
                        .catch(() => {
                            this.disabled = false;
                            this.innerHTML = original;
                            alert('Terjadi kesalahan');
                        });
                });
            });

        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PupukdanBriket\resources\views/user/shop.blade.php ENDPATH**/ ?>