

<?php $__env->startSection('content'); ?>
<div class="container py-5">

    <h3 class="mb-4">
        Hasil pencarian untuk: <strong><?php echo e($query); ?></strong>
    </h3>

    <?php if($products->count() == 0): ?>
        <p class="text-muted">Tidak ada produk ditemukan.</p>
    <?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-4">
                <div class="card h-100 shadow-sm">

                    <?php if($product->image && file_exists(public_path($product->image))): ?>
                        <img src="<?php echo e(asset($product->image)); ?>" 
                             class="card-img-top" 
                             style="height: 200px; object-fit: cover;"
                             alt="<?php echo e($product->name); ?>">
                    <?php else: ?>
                        <div class="bg-secondary d-flex align-items-center justify-content-center" 
                             style="height: 200px;">
                            <span class="text-white">No Image Available</span>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($product->name); ?></h5>

                        <p class="fw-bold text-primary">
                            Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?>

                        </p>

                        <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success w-100">
                                Add to Cart
                            </button>
                        </form>

                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PupukdanBriket\resources\views/user/search.blade.php ENDPATH**/ ?>