

<?php $__env->startSection('content'); ?>
<h3 class="mb-3">Produk yang Saya Pasok</h3>

<table class="table table-bordered align-middle">
    <thead class="table-light">
        <tr>
            <th>Foto</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                
                <td>
                    <?php if($item->image): ?>
                        <img src="<?php echo e(asset($item->image)); ?>"
                             alt="<?php echo e($item->name); ?>"
                             width="70">
                    <?php else: ?>
                        <span>-</span>
                    <?php endif; ?>
                </td>

                
                <td><?php echo e($item->name); ?></td>

                
                <td>Rp <?php echo e(number_format($item->price)); ?></td>

                
                <td><?php echo e($item->stock); ?></td>

                
                <td>
                    <span class="badge bg-<?php echo e($item->status === 'active' ? 'success' : 'secondary'); ?>">
                        <?php echo e(ucfirst($item->status)); ?>

                    </span>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center text-muted">
                    Belum ada produk.
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.produsen', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PupukdanBriket\resources\views/produsen/products/index.blade.php ENDPATH**/ ?>