

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container mt-5">
    <h1>Ecommerce Management</h1>

    <div class="row mt-4">
      <div class="col-md-3">
        <div class="card text-center h-100">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title">Total Products</h5>
            <h2 class="text-primary"><?php echo e(count($products)); ?></h2>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-primary mt-auto">Manage Products</a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="card text-center h-100">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title">Categories</h5>
            <h2 class="text-success"><?php echo e(count($categories)); ?></h2>
            <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-success mt-auto">Manage Categories</a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="card text-center h-100">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title">Orders</h5>
            <h2 class="text-warning">0</h2>
            <a href="<?php echo e(route('admin.purchase-history.index')); ?>" class="btn btn-warning mt-auto">View Orders</a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="card text-center h-100">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title">Revenue</h5>
            <h2 class="text-info">Rp 0</h2>
            <a href="<?php echo e(route('admin.reports.sales')); ?>" class="btn btn-info mt-auto">View Reports</a>
          </div>
        </div>
      </div>
    </div>

    <div class="row mt-5">
      <div class="col-md-12">
        <h3>Recent Products</h3>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Image</th>
              <th>Name</th>
              <th>Category</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($product->id); ?></td>
                <td>
                  <?php if($product->image): ?>
                    <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>" width="50" height="50"
                      style="object-fit: cover;">
                  <?php else: ?>
                    <img src="https://via.placeholder.com/50" alt="No Image" width="50">
                  <?php endif; ?>
                </td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->category->name ?? '-'); ?></td>
                <td>Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></td>
                <td><?php echo e($product->stock); ?></td>
                <td>
                  <span class="badge bg-<?php echo e($product->status == 'active' ? 'success' : 'danger'); ?>">
                    <?php echo e(ucfirst($product->status)); ?>

                  </span>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="7" class="text-center">No products yet. <a href="<?php echo e(route('admin.products.create')); ?>">Add
                    your first product</a></td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PupukdanBriket\resources\views/admin/ecommerce.blade.php ENDPATH**/ ?>