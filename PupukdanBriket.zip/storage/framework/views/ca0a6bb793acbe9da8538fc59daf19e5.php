

<?php $__env->startSection('content'); ?>

    <div class="container py-5">

        <h2 class="mb-4 fw-bold"><?php echo e($category->name); ?></h2>

        <?php if($products->count() > 0): ?>

            <div class="row g-4">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6">

                        <div class="product-item">
                            <figure>
                                <a href="#">
                                    <img src="<?php echo e(asset($product->image)); ?>" class="card-img-top"
                                        style="height: 200px; object-fit: cover;">
                                </a>
                            </figure>

                            <div class="p-3 text-center">
                                <h3 class="fs-6 fw-normal mb-2"><?php echo e($product->name); ?></h3>
                                <div class="d-flex justify-content-center gap-2 mb-3">
                                    <span class="text-dark fw-bold fs-5">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                                </div>
                                
                                <!-- TOMBOL AJAX - TIDAK PAKAI FORM -->
                                <button 
                                    type="button" 
                                    class="btn btn-primary w-100 btn-add-to-cart"
                                    data-product-id="<?php echo e($product->id); ?>"
                                    data-product-name="<?php echo e($product->name); ?>">
                                    Add to Cart
                                </button>
                            </div>

                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="mt-4">
                <?php echo e($products->links()); ?>

            </div>

        <?php else: ?>

            <p class="text-muted mt-3">Tidak ada produk untuk kategori ini.</p>

        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    
    const buttons = document.querySelectorAll('.btn-add-to-cart');
    
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const productId = this.getAttribute('data-product-id');
            const productName = this.getAttribute('data-product-name');
            const originalText = this.textContent;
            
            this.disabled = true;
            this.textContent = 'Adding...';
            
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            
            fetch('/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    product_id: productId,
                    quantity: 1
                })
            })
            .then(response => response.json())
            .then(data => {
                this.disabled = false;
                this.textContent = originalText;
                
                if (data.success) {
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil!',
                            text: productName + ' berhasil ditambahkan ke keranjang',
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 3000,
                            timerProgressBar: true
                        });
                    } else {
                        alert('✓ ' + data.message);
                    }
                    
                    const cartBadge = document.querySelector('.cart-count');
                    if (cartBadge) {
                        cartBadge.textContent = data.cart_count;
                    }
                    
                    this.classList.remove('btn-primary');
                    this.classList.add('btn-success');
                    setTimeout(() => {
                        this.classList.remove('btn-success');
                        this.classList.add('btn-primary');
                    }, 1000);
                } else {
                    alert('✗ ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                this.disabled = false;
                this.textContent = originalText;
                alert('Terjadi kesalahan saat menambahkan produk');
            });
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\PupukdanBriket\resources\views/user/category/show.blade.php ENDPATH**/ ?>