<div class="offcanvas offcanvas-end" data-bs-scroll="true" tabindex="-1" id="offcanvasCart">
    <div class="offcanvas-header justify-content-center">
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div class="order-md-last">
            <h4 class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-primary">Your cart</span>
                <span class="badge bg-primary rounded-pill" id="cartCount"><?php echo e($cartCount ?? 0); ?></span>
            </h4>
            
            <ul class="list-group mb-3" id="cartItems">
                <?php $__empty_1 = true; $__currentLoopData = $cartItems ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="list-group-item d-flex justify-content-between lh-sm">
                    <div>
                        <h6 class="my-0"><?php echo e($item->product->name ?? 'Product not found'); ?></h6>
                        <small class="text-body-secondary">Qty: <?php echo e($item->quantity ?? 0); ?></small>
                    </div>
                    <span class="text-body-secondary">
                        $<?php echo e(number_format(($item->price ?? 0) * ($item->quantity ?? 0), 2)); ?>

                    </span>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="list-group-item text-center">
                    <p class="mb-0">Your cart is empty</p>
                    <small class="text-muted">Add items to get started</small>
                </li>
                <?php endif; ?>
                
                <?php if(isset($cartItems) && count($cartItems) > 0): ?>
                <li class="list-group-item d-flex justify-content-between">
                    <span><strong>Total (USD)</strong></span>
                    <strong id="cartTotal">$<?php echo e(number_format($cartTotal ?? 0, 2)); ?></strong>
                </li>
                <?php endif; ?>
            </ul>
  
            <?php if(isset($cartItems) && count($cartItems) > 0): ?>
            <a href="<?php echo e(route('user.checkout')); ?>" class="w-100 btn btn-primary btn-lg">Continue to checkout</a>
            <a href="<?php echo e(route('user.cart')); ?>" class="w-100 btn btn-outline-primary mt-2">View Cart</a>
            <?php else: ?>
            <a href="<?php echo e(route('home')); ?>" class="w-100 btn btn-primary btn-lg">Start Shopping</a>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\PupukdanBriket\resources\views/user/partials/offcanvas-cart.blade.php ENDPATH**/ ?>